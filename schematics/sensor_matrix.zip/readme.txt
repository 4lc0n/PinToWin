inside the sensor_matrix the schematic is located, 
within the allegro folder, the layout was stored with all associated files. 

inside thie parts-folder are all footprints, stp-files and pads located needed
for this project

thie PRIVATE_LIB contains all created parts like the stm32 breakout-board and
mosfet.

